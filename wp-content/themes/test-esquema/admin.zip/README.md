Test Esquema
========

1° Prueba de creacion de una plantilla One Page con Framework, ReduxCore, para Wordpress.

Posee 6 sesiones administrables, por medio de un panel de opciones. 

Versión: 0.1


Plantilla creada para Test de Esquema Medellin Colombia

Link: https://github.com/reduxframework/ReduxCore
